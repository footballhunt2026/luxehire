/* ==========================================================================
   Luxehire Car Rental — Frontend logic (backend-driven, no localStorage)
   ========================================================================== */

let FLEET = [];
let CONFIG = {};
let currentFilter = { search: "", category: "all", brand: "all", sort: "featured" };
let cardGalleryIndex = {};

document.addEventListener("DOMContentLoaded", async () => {
  bindNav();
  bindFAQ();
  bindModal();
  document.getElementById("year") && (document.getElementById("year").textContent = new Date().getFullYear());

  showCatalogSkeleton();

  try {
    const [fleet, config] = await Promise.all([LuxehireAPI.getFleet(), LuxehireAPI.getConfig()]);
    FLEET = fleet;
    CONFIG = config;
  } catch (e) {
    console.error(e);
    showCatalogError();
    return;
  }

  applyConfigToDOM();
  renderBrandStrip();
  populateFilters();
  bindToolbar();
  renderCatalog();

  // These two sections are optional (admin-managed) — only render if content exists.
  loadPromoCars();
  loadHeroImages();

  window.LuxehireAnimate && window.LuxehireAnimate.initReveal();
});

/* ---- Config-driven bits ---------------------------------------------------- */
function applyConfigToDOM() {
  document.querySelectorAll("[data-wa-link]").forEach(el => {
    const msg = el.getAttribute("data-wa-msg") || "Hi Luxehire, I'd like to know more about your cars.";
    el.href = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(msg)}`;
  });
  document.querySelectorAll("[data-wa-number]").forEach(el => { el.textContent = "+" + CONFIG.whatsapp; });
  document.querySelectorAll("[data-site-email]").forEach(el => {
    el.textContent = CONFIG.email;
    if (el.tagName === "A") el.href = "mailto:" + CONFIG.email;
  });
  document.querySelectorAll("[data-site-address]").forEach(el => { el.textContent = CONFIG.address; });
}

/* ---- Brand strip ------------------------------------------------------------ */
function renderBrandStrip() {
  const el = document.getElementById("brandStrip");
  if (!el) return;
  const brands = [...new Set(FLEET.map(c => c.brand))];
  const extra = ["Toyota", "Nissan", "BMW", "Mercedes-Benz", "Audi", "Land Rover", "Porsche", "Lamborghini", "Lexus", "Ferrari", "Bentley", "Rolls-Royce"];
  const all = [...new Set([...brands, ...extra])].slice(0, 12);
  el.innerHTML = all.map(b => `<div class="brand-chip">${esc(b)}</div>`).join("");
}

/* ---- Filters ------------------------------------------------------------------*/
function populateFilters() {
  const catSel = document.getElementById("filterCategory");
  const brandSel = document.getElementById("filterBrand");
  if (!catSel || !brandSel) return;
  const categories = [...new Set(FLEET.map(c => c.category))].sort();
  const brands = [...new Set(FLEET.map(c => c.brand))].sort();
  catSel.innerHTML = `<option value="all">All Categories</option>` + categories.map(c => `<option value="${escAttr(c)}">${esc(c)}</option>`).join("");
  brandSel.innerHTML = `<option value="all">All Brands</option>` + brands.map(b => `<option value="${escAttr(b)}">${esc(b)}</option>`).join("");
}

function bindToolbar() {
  const searchInput = document.getElementById("searchInput");
  const catSel = document.getElementById("filterCategory");
  const brandSel = document.getElementById("filterBrand");
  const sortSel = document.getElementById("sortSelect");
  if (searchInput) searchInput.addEventListener("input", e => { currentFilter.search = e.target.value.trim().toLowerCase(); renderCatalog(); });
  if (catSel) catSel.addEventListener("change", e => { currentFilter.category = e.target.value; renderCatalog(); });
  if (brandSel) brandSel.addEventListener("change", e => { currentFilter.brand = e.target.value; renderCatalog(); });
  if (sortSel) sortSel.addEventListener("change", e => { currentFilter.sort = e.target.value; renderCatalog(); });
}

function getFilteredFleet() {
  let list = FLEET.filter(c => {
    const q = currentFilter.search;
    const matchesSearch = !q || (c.name + " " + c.brand + " " + c.category).toLowerCase().includes(q);
    const matchesCat = currentFilter.category === "all" || c.category === currentFilter.category;
    const matchesBrand = currentFilter.brand === "all" || c.brand === currentFilter.brand;
    return matchesSearch && matchesCat && matchesBrand;
  });
  if (currentFilter.sort === "price-low") list.sort((a, b) => a.daily - b.daily);
  else if (currentFilter.sort === "price-high") list.sort((a, b) => b.daily - a.daily);
  else if (currentFilter.sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
  return list;
}

/* ---- Skeleton loading -------------------------------------------------------- */
function showCatalogSkeleton() {
  const grid = document.getElementById("catalogGrid");
  if (!grid) return;
  const count = parseInt(grid.getAttribute("data-limit") || "8", 10);
  grid.innerHTML = Array.from({ length: Math.min(count, 8) }).map(() => `
    <div class="car-card skeleton-card">
      <div class="skeleton skeleton-media"></div>
      <div class="car-body">
        <div class="skeleton skeleton-line" style="width:40%;height:11px;"></div>
        <div class="skeleton skeleton-line" style="width:70%;height:18px;margin-top:8px;"></div>
        <div class="skeleton skeleton-line" style="width:90%;height:12px;margin-top:14px;"></div>
        <div class="skeleton skeleton-line" style="width:60%;height:22px;margin-top:16px;"></div>
      </div>
    </div>`).join("");
}
function showCatalogError() {
  const grid = document.getElementById("catalogGrid");
  if (grid) grid.innerHTML = `<div class="empty-state"><h3>Couldn't load the fleet</h3><p>Please refresh the page. If this keeps happening, check that the backend server is running.</p></div>`;
}

/* ---- Catalog ------------------------------------------------------------------*/
function renderCatalog() {
  const grid = document.getElementById("catalogGrid");
  const countEl = document.getElementById("resultCount");
  if (!grid) return;

  const list = getFilteredFleet();
  const limit = grid.getAttribute("data-limit");
  const shown = limit ? list.slice(0, parseInt(limit, 10)) : list;

  if (countEl) countEl.textContent = `${list.length} vehicle${list.length === 1 ? "" : "s"} found`;

  if (shown.length === 0) {
    grid.innerHTML = `<div class="empty-state"><h3>No vehicles match your search</h3><p>Try a different keyword, brand, or category.</p></div>`;
    return;
  }

  grid.innerHTML = shown.map(car => carCardHTML(car)).join("");
  bindCardGalleries();
  renderIcons(grid);
}

function carCardHTML(car) {
  cardGalleryIndex[car.id] = 0;
  const waMsg = `Hi Luxehire, I'm interested in renting the ${car.name} (AED ${car.daily}/day). Is it available?`;
  return `
  <article class="car-card" data-id="${car.id}" data-animate>
    <div class="car-media" data-car="${car.id}">
      <img src="${car.images[0]}" alt="${esc(car.name)} rental Dubai" loading="lazy" data-img-idx="0">
      <div class="badge-row">
        ${car.noDeposit ? `<span class="badge badge-deposit">No Deposit</span>` : `<span></span>`}
        <span class="badge badge-category">${esc(car.category)}</span>
      </div>
      ${car.images.length > 1 ? `
      <button class="car-gallery-nav prev" aria-label="Previous image" data-nav="prev" data-car="${car.id}"><span class="icon icon-sm" data-icon="chevronLeft"></span></button>
      <button class="car-gallery-nav next" aria-label="Next image" data-nav="next" data-car="${car.id}"><span class="icon icon-sm" data-icon="chevronRight"></span></button>
      <div class="car-gallery-dots">
        ${car.images.map((_, i) => `<button class="${i === 0 ? "active" : ""}" data-dot="${i}" data-car="${car.id}"></button>`).join("")}
      </div>` : ""}
    </div>
    <div class="car-body">
      <span class="car-brand">${esc(car.brand)}</span>
      <h3 class="car-name">${esc(car.name)}</h3>
      <div class="car-specs">
        <span><span class="icon icon-sm" data-icon="seat"></span> ${car.seats} Seats</span>
        <span><span class="icon icon-sm" data-icon="gear"></span> ${esc(car.transmission)}</span>
        <span><span class="icon icon-sm" data-icon="fuel"></span> ${esc(car.fuel)}</span>
      </div>
      <div class="car-pricing">
        <div class="price-row main"><span>Daily</span><span class="val">AED ${fmt(car.daily)}</span></div>
        <div class="price-row"><span>Weekly</span><span class="val">AED ${fmt(car.weekly)}</span></div>
        <div class="price-row"><span>Monthly</span><span class="val">AED ${fmt(car.monthly)}</span></div>
      </div>
    </div>
    <div class="car-actions">
      <button class="btn btn-outline-dark btn-sm" style="flex:1" data-view="${car.id}">View Details</button>
      <a class="btn btn-whatsapp btn-sm" style="flex:1" href="https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(waMsg)}" target="_blank" rel="noopener">WhatsApp</a>
    </div>
  </article>`;
}

function bindCardGalleries() {
  document.querySelectorAll("[data-nav]").forEach(btn => {
    btn.addEventListener("click", () => {
      const carId = btn.getAttribute("data-car");
      const car = FLEET.find(c => c.id === carId);
      const dir = btn.getAttribute("data-nav") === "next" ? 1 : -1;
      let idx = cardGalleryIndex[carId] || 0;
      idx = (idx + dir + car.images.length) % car.images.length;
      cardGalleryIndex[carId] = idx;
      updateCardGallery(carId, idx);
    });
  });
  document.querySelectorAll("[data-dot]").forEach(dot => {
    dot.addEventListener("click", () => {
      const carId = dot.getAttribute("data-car");
      const idx = parseInt(dot.getAttribute("data-dot"), 10);
      cardGalleryIndex[carId] = idx;
      updateCardGallery(carId, idx);
    });
  });
  document.querySelectorAll("[data-view]").forEach(btn => {
    btn.addEventListener("click", () => openCarModal(btn.getAttribute("data-view")));
  });
}

function updateCardGallery(carId, idx) {
  const car = FLEET.find(c => c.id === carId);
  const media = document.querySelector(`.car-media[data-car="${carId}"]`);
  if (!media || !car) return;
  media.querySelector("img").src = car.images[idx];
  media.querySelectorAll("[data-dot]").forEach((d, i) => d.classList.toggle("active", i === idx));
}

/* ---- Promo cars section (admin-managed, optional) ----------------------------*/
async function loadPromoCars() {
  const section = document.getElementById("promoSection");
  const grid = document.getElementById("promoGrid");
  if (!section || !grid) return;
  try {
    const promos = await LuxehireAPI.getPromoCars();
    if (!promos.length) { section.style.display = "none"; return; }
    section.style.display = "";
    grid.innerHTML = promos.map(p => promoCardHTML(p)).join("");
    bindCardGalleries();
    renderIcons(grid);
    window.LuxehireAnimate && window.LuxehireAnimate.initReveal(grid);
  } catch (e) {
    console.error(e);
    section.style.display = "none";
  }
}
function promoCardHTML(p) {
  const car = p.car;
  const waMsg = `Hi Luxehire, I saw the ${esc(car.name)} promo — is it still available?`;
  return `
  <article class="car-card promo-card" data-id="${car.id}" data-animate>
    <div class="car-media" data-car="${car.id}">
      <img src="${car.images[0]}" alt="${esc(car.name)} promo Dubai" loading="lazy">
      <div class="badge-row"><span class="badge badge-promo">${esc(p.badgeText)}</span><span class="badge badge-category">${esc(car.category)}</span></div>
    </div>
    <div class="car-body">
      <span class="car-brand">${esc(car.brand)}</span>
      <h3 class="car-name">${esc(car.name)}</h3>
      <div class="car-pricing">
        <div class="price-row main"><span>Daily</span><span class="val">AED ${fmt(car.daily)}</span></div>
      </div>
    </div>
    <div class="car-actions">
      <button class="btn btn-outline-dark btn-sm" style="flex:1" data-view="${car.id}">View Details</button>
      <a class="btn btn-whatsapp btn-sm" style="flex:1" href="https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(waMsg)}" target="_blank" rel="noopener">WhatsApp</a>
    </div>
  </article>`;
}

/* ---- Customer hero images section (admin-managed, optional) ------------------*/
async function loadHeroImages() {
  const section = document.getElementById("customerHeroSection");
  const track = document.getElementById("customerHeroTrack");
  if (!section || !track) return;
  try {
    const images = await LuxehireAPI.getHeroImages();
    if (!images.length) { section.style.display = "none"; return; }
    section.style.display = "";
    track.innerHTML = images.map(h => `
      <figure class="customer-hero-item" data-animate>
        <img src="${escAttr(h.url)}" alt="${escAttr(h.caption || "Happy Luxehire customer")}" loading="lazy">
        ${h.caption ? `<figcaption>${esc(h.caption)}</figcaption>` : ""}
      </figure>`).join("");
    window.LuxehireAnimate && window.LuxehireAnimate.initReveal(track);
  } catch (e) {
    console.error(e);
    section.style.display = "none";
  }
}

/* ---- Modal (quick view) -------------------------------------------------------*/
let modalGalleryIndex = 0;
let modalCar = null;

function bindModal() {
  const overlay = document.getElementById("carModal");
  if (!overlay) return;
  overlay.addEventListener("click", e => { if (e.target === overlay) closeModal(); });
  document.getElementById("modalClose")?.addEventListener("click", closeModal);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
}

function openCarModal(carId) {
  const car = FLEET.find(c => c.id === carId);
  if (!car) return;
  modalCar = car;
  modalGalleryIndex = 0;
  const overlay = document.getElementById("carModal");
  if (!overlay) return;

  document.getElementById("modalMainImg").src = car.images[0];
  document.getElementById("modalMainImg").alt = car.name;
  document.getElementById("modalThumbs").innerHTML = car.images.map((img, i) =>
    `<img src="${img}" class="${i === 0 ? "active" : ""}" data-thumb="${i}" alt="${esc(car.name)} view ${i + 1}">`
  ).join("");
  document.getElementById("modalTitle").textContent = car.name;
  document.getElementById("modalBrandCat").textContent = `${car.brand} · ${car.category} · ${car.year}`;
  document.getElementById("modalSpecs").innerHTML = `
    <span><span class="icon icon-sm" data-icon="seat"></span> ${car.seats} Seats</span> &nbsp;·&nbsp;
    <span><span class="icon icon-sm" data-icon="gear"></span> ${esc(car.transmission)}</span> &nbsp;·&nbsp;
    <span><span class="icon icon-sm" data-icon="fuel"></span> ${esc(car.fuel)}</span>`;
  document.getElementById("modalFeatures").innerHTML = car.features.map(f => `<li>${esc(f)}</li>`).join("");
  document.getElementById("modalPriceTable").innerHTML = `
    <tr><td>Daily Rate</td><td>AED ${fmt(car.daily)}</td></tr>
    <tr><td>Weekly Rate</td><td>AED ${fmt(car.weekly)}</td></tr>
    <tr><td>Monthly Rate</td><td>AED ${fmt(car.monthly)}</td></tr>
    ${car.noDeposit ? `<tr><td>No-Deposit Service Fee</td><td>AED ${fmt(car.depositFee)}</td></tr>` : ""}
  `;
  const waMsg = `Hi Luxehire, I'm interested in renting the ${car.name} (AED ${car.daily}/day). Is it available?`;
  document.getElementById("modalWhatsapp").href = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(waMsg)}`;

  document.getElementById("modalThumbs").querySelectorAll("[data-thumb]").forEach(t => {
    t.addEventListener("click", () => {
      const i = parseInt(t.getAttribute("data-thumb"), 10);
      modalGalleryIndex = i;
      document.getElementById("modalMainImg").src = car.images[i];
      document.getElementById("modalThumbs").querySelectorAll("img").forEach((x, xi) => x.classList.toggle("active", xi === i));
    });
  });

  overlay.classList.add("active");
  document.body.style.overflow = "hidden";
  renderIcons(overlay);
}

function closeModal() {
  const overlay = document.getElementById("carModal");
  if (!overlay) return;
  overlay.classList.remove("active");
  document.body.style.overflow = "";
}

/* ---- Mobile nav -----------------------------------------------------------------*/
function bindNav() {
  const toggle = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
}

/* ---- FAQ accordion — exactly one item open at a time --------------------------*/
function bindFAQ() {
  document.querySelectorAll(".faq-item").forEach(item => {
    item.querySelector(".faq-q")?.addEventListener("click", () => {
      const wasOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item").forEach(i => i.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
    });
  });
}

/* ---- Helpers ----------------------------------------------------------------------*/
function fmt(n) { return Number(n).toLocaleString("en-AE"); }
function esc(s) { return String(s).replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])); }
function escAttr(s) { return esc(s); }
