/* ==========================================================================
   Luxehire Car Rental — Backend server
   Plain Node.js (no Express, no npm install needed — just `node server.js`).
   Serves the static site from /public and a JSON API from /api/*.
   ========================================================================== */
"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

loadDotEnv();

const store = require("./store");
const auth = require("./auth");
const seed = require("./seed");

const PORT = parseInt(process.env.PORT, 10) || 3000;
const PUBLIC_DIR = path.join(__dirname, "..", "public");
const UPLOAD_DIRS = {
  cars: path.join(PUBLIC_DIR, "uploads", "cars"),
  hero: path.join(PUBLIC_DIR, "uploads", "hero"),
  promo: path.join(PUBLIC_DIR, "uploads", "promo")
};
Object.values(UPLOAD_DIRS).forEach(d => fs.mkdirSync(d, { recursive: true }));

const MAX_UPLOAD_BYTES = 6 * 1024 * 1024; // 6MB decoded
const MAX_BODY_BYTES = 9 * 1024 * 1024; // raw request body cap (base64 is ~33% bigger)

auth.ensureAdmin();

/* ---- tiny .env loader (no dependency) -------------------------------------- */
function loadDotEnv() {
  try {
    const envPath = path.join(__dirname, "..", ".env");
    if (!fs.existsSync(envPath)) return;
    const lines = fs.readFileSync(envPath, "utf8").split("\n");
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const idx = trimmed.indexOf("=");
      if (idx === -1) continue;
      const key = trimmed.slice(0, idx).trim();
      let val = trimmed.slice(idx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!(key in process.env)) process.env[key] = val;
    }
  } catch (e) { /* .env is optional */ }
}

/* ---- MIME types -------------------------------------------------------------- */
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".xml": "application/xml; charset=utf-8",
  ".txt": "text/plain; charset=utf-8"
};

/* ---- Security headers applied to every response ------------------------------ */
function applySecurityHeaders(req, res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "geolocation=(), camera=(), microphone=()");
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; " +
    "img-src 'self' data: https:; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; " +
    "script-src 'self'; " +
    "connect-src 'self'; " +
    "frame-ancestors 'none'; " +
    "base-uri 'self'; form-action 'self'"
  );
  const isHttps = req.headers["x-forwarded-proto"] === "https" || req.socket.encrypted;
  if (isHttps) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
}

function clientIp(req) {
  const fwd = req.headers["x-forwarded-for"];
  if (fwd) return fwd.split(",")[0].trim();
  return req.socket.remoteAddress || "unknown";
}

/* ---- Body helpers -------------------------------------------------------------*/
function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", chunk => {
      size += chunk.length;
      if (size > (maxBytes || MAX_BODY_BYTES)) {
        reject(Object.assign(new Error("Payload too large"), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

async function readJSONBody(req, maxBytes) {
  const buf = await readBody(req, maxBytes);
  if (!buf.length) return {};
  try {
    return JSON.parse(buf.toString("utf8"));
  } catch (e) {
    throw Object.assign(new Error("Invalid JSON body"), { statusCode: 400 });
  }
}

function sendJSON(res, statusCode, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function sendError(res, statusCode, message) {
  sendJSON(res, statusCode, { error: message || "Something went wrong" });
}

/* ---- Session helper: resolve the current admin session from cookies ---------- */
function getRequestSession(req) {
  const cookies = auth.parseCookies(req.headers.cookie);
  const token = cookies[auth.SESSION_COOKIE];
  const session = auth.getSession(token);
  return session ? { token, session } : null;
}

function setSessionCookie(req, res, token, maxAgeSeconds) {
  const isHttps = req.headers["x-forwarded-proto"] === "https" || req.socket.encrypted;
  const parts = [
    `${auth.SESSION_COOKIE}=${token}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${maxAgeSeconds}`
  ];
  if (isHttps) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

function clearSessionCookie(req, res) {
  setSessionCookie(req, res, "", 0);
}

/** Require a valid session + matching CSRF header for mutating admin requests. */
function requireAdmin(req, res, { checkCsrf } = { checkCsrf: true }) {
  const found = getRequestSession(req);
  if (!found) {
    sendError(res, 401, "Not authenticated. Please log in again.");
    return null;
  }
  if (checkCsrf) {
    const provided = req.headers["x-csrf-token"];
    if (!provided || provided !== found.session.csrf) {
      sendError(res, 403, "Invalid or missing CSRF token.");
      return null;
    }
  }
  return found;
}

/* ---- Small validation / sanitizing helpers ------------------------------------ */
function s(v, fallback) { return typeof v === "string" ? v.trim() : (fallback !== undefined ? fallback : ""); }
function num(v, fallback) { const n = Number(v); return Number.isFinite(n) ? n : (fallback !== undefined ? fallback : 0); }
function bool(v) { return v === true || v === "true"; }
function newId(prefix) { return prefix + Date.now().toString(36) + crypto.randomBytes(3).toString("hex"); }

function sanitizeCar(input, existingId) {
  const images = Array.isArray(input.images) ? input.images.map(u => s(u)).filter(Boolean) : [];
  const features = Array.isArray(input.features) ? input.features.map(f => s(f)).filter(Boolean) : [];
  if (!s(input.name)) throw Object.assign(new Error("Car name is required."), { statusCode: 400 });
  if (images.length < 1) throw Object.assign(new Error("At least one image is required."), { statusCode: 400 });
  return {
    id: existingId || newId("c"),
    name: s(input.name),
    brand: s(input.brand),
    category: s(input.category),
    seats: Math.max(1, Math.round(num(input.seats, 4))),
    transmission: s(input.transmission, "Automatic"),
    fuel: s(input.fuel, "Petrol"),
    year: Math.round(num(input.year, new Date().getFullYear())),
    daily: Math.max(0, num(input.daily, 0)),
    weekly: Math.max(0, num(input.weekly, 0)),
    monthly: Math.max(0, num(input.monthly, 0)),
    noDeposit: bool(input.noDeposit),
    depositFee: Math.max(0, num(input.depositFee, 0)),
    features,
    images
  };
}

/* ---- Image upload (base64 JSON payload — no multipart parser needed) --------- */
const ALLOWED_IMAGE_TYPES = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif" };

async function handleUpload(req, res, category) {
  const auth1 = requireAdmin(req, res);
  if (!auth1) return;
  if (!UPLOAD_DIRS[category]) return sendError(res, 400, "Unknown upload category.");

  let body;
  try { body = await readJSONBody(req, MAX_BODY_BYTES); }
  catch (e) { return sendError(res, e.statusCode || 400, e.message); }

  const dataUrl = s(body.dataUrl);
  const match = /^data:(image\/[a-zA-Z+]+);base64,(.+)$/.exec(dataUrl);
  if (!match) return sendError(res, 400, "Expected an image data URL (PNG, JPG, WEBP or GIF).");
  const mime = match[1].toLowerCase();
  const ext = ALLOWED_IMAGE_TYPES[mime];
  if (!ext) return sendError(res, 400, "Unsupported image type. Use PNG, JPG, WEBP or GIF.");

  const buffer = Buffer.from(match[2], "base64");
  if (buffer.length === 0) return sendError(res, 400, "Empty image data.");
  if (buffer.length > MAX_UPLOAD_BYTES) return sendError(res, 413, "Image is too large (max 6MB).");

  const filename = `${Date.now().toString(36)}-${crypto.randomBytes(4).toString("hex")}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIRS[category], filename), buffer);
  sendJSON(res, 201, { url: `/uploads/${category}/${filename}` });
}

/* ---- Static file serving -------------------------------------------------------*/
function safeJoin(base, requestPath) {
  const decoded = decodeURIComponent(requestPath.split("?")[0]);
  const resolved = path.normalize(path.join(base, decoded));
  if (!resolved.startsWith(base)) return null; // path traversal guard
  return resolved;
}

function serveStatic(req, res, pathname) {
  let filePath = safeJoin(PUBLIC_DIR, pathname === "/" ? "/index.html" : pathname);
  if (!filePath) return sendError(res, 400, "Bad request path.");

  fs.stat(filePath, (err, stat) => {
    if (!err && stat.isDirectory()) {
      filePath = path.join(filePath, "index.html");
    }
    fs.readFile(filePath, (err2, data) => {
      if (err2) {
        // SPA-style pretty URLs aren't needed here; just 404.
        res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
        res.end("<h1>404 Not Found</h1>");
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const headers = { "Content-Type": MIME[ext] || "application/octet-stream" };
      // Admin pages must never be cached or indexed by intermediaries.
      if (pathname.startsWith("/admin/")) {
        headers["Cache-Control"] = "no-store";
      } else if (ext === ".html") {
        headers["Cache-Control"] = "no-cache";
      } else {
        headers["Cache-Control"] = "public, max-age=3600";
      }
      res.writeHead(200, headers);
      res.end(data);
    });
  });
}

/* ==============================================================================
   ROUTES
   ============================================================================== */
async function handleApi(req, res, url) {
  const { pathname } = url;
  const method = req.method;

  /* ---------- PUBLIC: fleet ---------- */
  if (method === "GET" && pathname === "/api/fleet") {
    return sendJSON(res, 200, store.readJSON("fleet", seed.DEFAULT_FLEET));
  }

  /* ---------- PUBLIC: config (safe subset only) ---------- */
  if (method === "GET" && pathname === "/api/config") {
    const cfg = store.readJSON("config", seed.DEFAULT_CONFIG);
    return sendJSON(res, 200, cfg);
  }

  /* ---------- PUBLIC: hero images ---------- */
  if (method === "GET" && pathname === "/api/hero-images") {
    const list = store.readJSON("hero-images", seed.DEFAULT_HERO_IMAGES);
    return sendJSON(res, 200, list.filter(h => h.active !== false).sort((a, b) => (a.order || 0) - (b.order || 0)));
  }

  /* ---------- PUBLIC: promo cars (joined with live fleet data) ---------- */
  if (method === "GET" && pathname === "/api/promo-cars") {
    const promos = store.readJSON("promo-cars", seed.DEFAULT_PROMO_CARS);
    const fleet = store.readJSON("fleet", seed.DEFAULT_FLEET);
    const joined = promos
      .filter(p => p.active !== false)
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map(p => {
        const car = fleet.find(c => c.id === p.carId);
        if (!car) return null;
        return { id: p.id, badgeText: p.badgeText || "Promo", car };
      })
      .filter(Boolean);
    return sendJSON(res, 200, joined);
  }

  /* ---------- ADMIN: auth ---------- */
  if (method === "POST" && pathname === "/api/admin/login") {
    const ip = clientIp(req);
    if (auth.isRateLimited(ip)) {
      return sendError(res, 429, "Too many login attempts. Try again in a few minutes.");
    }
    let body;
    try { body = await readJSONBody(req, 4096); }
    catch (e) { return sendError(res, e.statusCode || 400, e.message); }

    const record = store.readJSON("admin", null);
    const ok = record && auth.verifyPassword(s(body.password), record.salt, record.hash);
    if (!ok) {
      auth.recordLoginFailure(ip);
      return sendError(res, 401, "Incorrect password.");
    }
    auth.clearLoginFailures(ip);
    const { token, csrf } = auth.createSession();
    setSessionCookie(req, res, token, 3600);
    return sendJSON(res, 200, { csrfToken: csrf });
  }

  if (method === "POST" && pathname === "/api/admin/logout") {
    const found = getRequestSession(req);
    if (found) auth.destroySession(found.token);
    clearSessionCookie(req, res);
    return sendJSON(res, 200, { ok: true });
  }

  if (method === "GET" && pathname === "/api/admin/me") {
    const found = getRequestSession(req);
    if (!found) return sendError(res, 401, "Not authenticated.");
    return sendJSON(res, 200, { authenticated: true, csrfToken: found.session.csrf });
  }

  if (method === "POST" && pathname === "/api/admin/change-password") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let body;
    try { body = await readJSONBody(req, 4096); }
    catch (e) { return sendError(res, e.statusCode || 400, e.message); }

    const record = store.readJSON("admin", null);
    if (!record || !auth.verifyPassword(s(body.currentPassword), record.salt, record.hash)) {
      return sendError(res, 401, "Current password is incorrect.");
    }
    const newPassword = s(body.newPassword);
    if (newPassword.length < 8) {
      return sendError(res, 400, "New password must be at least 8 characters.");
    }
    const { salt, hash } = auth.hashPassword(newPassword);
    store.writeJSONSync("admin", { salt, hash });
    return sendJSON(res, 200, { ok: true });
  }

  /* ---------- ADMIN: fleet CRUD ---------- */
  if (method === "POST" && pathname === "/api/admin/fleet") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let body;
    try { body = await readJSONBody(req); } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    try {
      const car = sanitizeCar(body);
      store.update("fleet", seed.DEFAULT_FLEET, list => list.push(car));
      return sendJSON(res, 201, car);
    } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
  }

  const fleetIdMatch = pathname.match(/^\/api\/admin\/fleet\/([a-zA-Z0-9_-]+)$/);
  if (fleetIdMatch && (method === "PUT" || method === "DELETE")) {
    const found = requireAdmin(req, res);
    if (!found) return;
    const id = fleetIdMatch[1];

    if (method === "DELETE") {
      let existed = false;
      store.update("fleet", seed.DEFAULT_FLEET, list => {
        const idx = list.findIndex(c => c.id === id);
        if (idx !== -1) { list.splice(idx, 1); existed = true; }
      });
      if (!existed) return sendError(res, 404, "Car not found.");
      return sendJSON(res, 200, { ok: true });
    }

    // PUT
    let body;
    try { body = await readJSONBody(req); } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    let updated = null;
    try {
      store.update("fleet", seed.DEFAULT_FLEET, list => {
        const idx = list.findIndex(c => c.id === id);
        if (idx === -1) throw Object.assign(new Error("Car not found."), { statusCode: 404 });
        updated = sanitizeCar(body, id);
        list[idx] = updated;
      });
    } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    return sendJSON(res, 200, updated);
  }

  if (method === "POST" && pathname === "/api/admin/fleet-reset") {
    const found = requireAdmin(req, res);
    if (!found) return;
    store.writeJSONSync("fleet", seed.DEFAULT_FLEET);
    return sendJSON(res, 200, seed.DEFAULT_FLEET);
  }

  /* ---------- ADMIN: config ---------- */
  if (method === "PUT" && pathname === "/api/admin/config") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let body;
    try { body = await readJSONBody(req, 8192); } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    const wa = s(body.whatsapp).replace(/\D/g, "");
    if (wa.length < 8) return sendError(res, 400, "Enter a valid WhatsApp number with country code.");
    const cfg = {
      whatsapp: wa,
      siteName: s(body.siteName, "Luxehire Car Rental"),
      email: s(body.email),
      domain: s(body.domain, "luxehirecarrental.xyz"),
      address: s(body.address)
    };
    store.writeJSONSync("config", cfg);
    return sendJSON(res, 200, cfg);
  }

  /* ---------- ADMIN: hero images ---------- */
  if (method === "POST" && pathname === "/api/admin/hero-images") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let body;
    try { body = await readJSONBody(req); } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    if (!s(body.url)) return sendError(res, 400, "Image URL is required.");
    const entry = { id: newId("h"), url: s(body.url), caption: s(body.caption), order: Date.now(), active: true };
    store.update("hero-images", seed.DEFAULT_HERO_IMAGES, list => list.push(entry));
    return sendJSON(res, 201, entry);
  }

  const heroIdMatch = pathname.match(/^\/api\/admin\/hero-images\/([a-zA-Z0-9_-]+)$/);
  if (heroIdMatch && method === "DELETE") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let existed = false;
    store.update("hero-images", seed.DEFAULT_HERO_IMAGES, list => {
      const idx = list.findIndex(h => h.id === heroIdMatch[1]);
      if (idx !== -1) { list.splice(idx, 1); existed = true; }
    });
    if (!existed) return sendError(res, 404, "Hero image not found.");
    return sendJSON(res, 200, { ok: true });
  }

  /* ---------- ADMIN: promo cars ---------- */
  if (method === "POST" && pathname === "/api/admin/promo-cars") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let body;
    try { body = await readJSONBody(req); } catch (e) { return sendError(res, e.statusCode || 400, e.message); }
    const fleet = store.readJSON("fleet", seed.DEFAULT_FLEET);
    if (!fleet.some(c => c.id === s(body.carId))) return sendError(res, 400, "Select a valid car for this promo.");
    const entry = { id: newId("p"), carId: s(body.carId), badgeText: s(body.badgeText, "Promo"), order: Date.now(), active: true };
    store.update("promo-cars", seed.DEFAULT_PROMO_CARS, list => list.push(entry));
    return sendJSON(res, 201, entry);
  }

  const promoIdMatch = pathname.match(/^\/api\/admin\/promo-cars\/([a-zA-Z0-9_-]+)$/);
  if (promoIdMatch && method === "DELETE") {
    const found = requireAdmin(req, res);
    if (!found) return;
    let existed = false;
    store.update("promo-cars", seed.DEFAULT_PROMO_CARS, list => {
      const idx = list.findIndex(p => p.id === promoIdMatch[1]);
      if (idx !== -1) { list.splice(idx, 1); existed = true; }
    });
    if (!existed) return sendError(res, 404, "Promo entry not found.");
    return sendJSON(res, 200, { ok: true });
  }

  /* ---------- ADMIN: image upload ---------- */
  if (method === "POST" && pathname === "/api/admin/upload/cars") return handleUpload(req, res, "cars");
  if (method === "POST" && pathname === "/api/admin/upload/hero") return handleUpload(req, res, "hero");
  if (method === "POST" && pathname === "/api/admin/upload/promo") return handleUpload(req, res, "promo");

  /* ---------- ADMIN: overview stats (small convenience endpoint) ---------- */
  if (method === "GET" && pathname === "/api/admin/overview") {
    const found = requireAdmin(req, res, { checkCsrf: false });
    if (!found) return;
    const fleet = store.readJSON("fleet", seed.DEFAULT_FLEET);
    return sendJSON(res, 200, {
      totalCars: fleet.length,
      noDepositCars: fleet.filter(c => c.noDeposit).length,
      avgDaily: fleet.length ? Math.round(fleet.reduce((sum, c) => sum + Number(c.daily || 0), 0) / fleet.length) : 0,
      brands: new Set(fleet.map(c => c.brand)).size
    });
  }

  return sendError(res, 404, "Not found.");
}

/* ==============================================================================
   SERVER
   ============================================================================== */
const server = http.createServer(async (req, res) => {
  applySecurityHeaders(req, res);
  let url;
  try {
    url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  } catch (e) {
    res.writeHead(400).end("Bad request");
    return;
  }

  if (url.pathname.startsWith("/api/")) {
    try {
      await handleApi(req, res, url);
    } catch (e) {
      console.error("[api] Unhandled error:", e);
      if (!res.headersSent) sendError(res, e.statusCode || 500, e.statusCode ? e.message : "Server error.");
    }
    return;
  }

  if (req.method === "GET" || req.method === "HEAD") {
    serveStatic(req, res, url.pathname);
    return;
  }

  res.writeHead(405, { "Content-Type": "text/plain" }).end("Method not allowed");
});

server.listen(PORT, () => {
  console.log(`Luxehire server running at http://localhost:${PORT}`);
  console.log(`Admin panel:            http://localhost:${PORT}/admin/login.html`);
});
