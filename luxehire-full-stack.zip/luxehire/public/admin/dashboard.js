/* ==========================================================================
   Luxehire Admin — Dashboard logic. Everything here goes through the
   backend API (session cookie + CSRF token) — nothing is stored client-side.
   ========================================================================== */

let fleet = [];
let heroImages = [];
let promoCars = [];
let editingCarId = null;
let currentFeatures = [];
let currentImages = [];
let pendingHeroUrl = null;

(async function init() {
  try {
    await LuxehireAPI.me(); // throws if not authenticated — csrfToken is set on success
  } catch (e) {
    window.location.href = "login.html";
    return;
  }

  bindNavTabs();
  bindCarForm();
  bindSettingsForm();
  bindPasswordForm();
  bindDataButtons();
  bindFleetSearch();
  bindLogout();
  bindSidebarToggle();
  bindHeroTab();
  bindPromoTab();

  await Promise.all([loadFleet(), loadHeroImages(), loadPromoCars()]);
  renderOverview();
  renderFleetTable();
  buildImageInputs();
  fillSettingsForm();
  renderHeroList();
  renderPromoList();
  populatePromoCarSelect();

  // idle-session watchdog: bounce to login if session expires mid-use
  setInterval(async () => {
    try { await LuxehireAPI.me(); } catch (e) { window.location.href = "login.html"; }
  }, 60000);
})();

async function loadFleet() { fleet = await LuxehireAPI.getFleet(); }
async function loadHeroImages() { heroImages = await LuxehireAPI.getHeroImages(); }
async function loadPromoCars() { promoCars = await LuxehireAPI.getPromoCars(); }

/* ---- Tabs -------------------------------------------------------------------*/
function bindNavTabs() {
  document.querySelectorAll(".admin-nav button[data-tab]").forEach(btn => {
    btn.addEventListener("click", () => switchTab(btn.getAttribute("data-tab")));
  });
}
function switchTab(tab) {
  document.querySelectorAll(".admin-nav button[data-tab]").forEach(b => b.classList.toggle("active", b.getAttribute("data-tab") === tab));
  document.querySelectorAll(".admin-tab").forEach(sec => sec.style.display = "none");
  document.getElementById("tab-" + tab).style.display = "block";
  const titles = { overview: "Overview", fleet: "Manage Fleet", "add-car": editingCarId ? "Edit Car" : "Add New Car", hero: "Customer Hero Images", promo: "Promo Cars", settings: "Settings" };
  document.getElementById("pageTitle").textContent = titles[tab] || "Dashboard";
  if (tab !== "add-car" && editingCarId) resetCarForm();
}

/* ---- Overview -----------------------------------------------------------------*/
function renderOverview() {
  document.getElementById("statTotalCars").textContent = fleet.length;
  document.getElementById("statNoDeposit").textContent = fleet.filter(c => c.noDeposit).length;
  const avg = fleet.length ? Math.round(fleet.reduce((sum, c) => sum + Number(c.daily), 0) / fleet.length) : 0;
  document.getElementById("statAvgPrice").textContent = avg.toLocaleString();
  document.getElementById("statBrands").textContent = new Set(fleet.map(c => c.brand)).size;

  const recent = [...fleet].slice(-5).reverse();
  document.getElementById("recentCarsBody").innerHTML = recent.map(c => `
    <tr>
      <td><img src="${escAttr(c.images[0])}" alt="${esc(c.name)}"></td>
      <td>${esc(c.name)}</td>
      <td>${esc(c.brand)}</td>
      <td>AED ${fmt(c.daily)}</td>
      <td>${c.noDeposit ? '<span class="chip-deposit">Yes</span>' : '<span class="chip-off">No</span>'}</td>
    </tr>`).join("") || `<tr><td colspan="5" style="text-align:center;color:var(--steel-600);">No vehicles yet.</td></tr>`;
  renderIcons(document.getElementById("tab-overview"));
}

/* ---- Fleet table ----------------------------------------------------------------*/
let fleetSearchTerm = "";
function renderFleetTable() {
  const body = document.getElementById("fleetTableBody");
  const list = fleet.filter(c => !fleetSearchTerm || (c.name + c.brand + c.category).toLowerCase().includes(fleetSearchTerm));
  body.innerHTML = list.map(c => `
    <tr>
      <td><img src="${escAttr(c.images[0])}" alt="${esc(c.name)}"></td>
      <td><strong>${esc(c.name)}</strong></td>
      <td>${esc(c.brand)}<br><span style="color:var(--steel-600);font-size:12px;">${esc(c.category)}</span></td>
      <td>AED ${fmt(c.daily)}</td>
      <td>AED ${fmt(c.weekly)}</td>
      <td>AED ${fmt(c.monthly)}</td>
      <td>${c.noDeposit ? '<span class="chip-deposit">Yes</span>' : '<span class="chip-off">No</span>'}</td>
      <td>
        <div class="row-actions">
          <button data-edit="${c.id}" aria-label="Edit"><span class="icon icon-sm" data-icon="edit"></span></button>
          <button data-delete="${c.id}" class="danger" aria-label="Delete"><span class="icon icon-sm" data-icon="trash"></span></button>
        </div>
      </td>
    </tr>`).join("") || `<tr><td colspan="8" style="text-align:center;color:var(--steel-600);">No vehicles match your search.</td></tr>`;

  body.querySelectorAll("[data-edit]").forEach(btn => btn.addEventListener("click", () => loadCarIntoForm(btn.getAttribute("data-edit"))));
  body.querySelectorAll("[data-delete]").forEach(btn => btn.addEventListener("click", () => deleteCar(btn.getAttribute("data-delete"))));
  renderIcons(body);
}

function bindFleetSearch() {
  document.getElementById("fleetSearch").addEventListener("input", e => {
    fleetSearchTerm = e.target.value.trim().toLowerCase();
    renderFleetTable();
  });
}

async function deleteCar(id) {
  const car = fleet.find(c => c.id === id);
  if (!car) return;
  if (!confirm(`Delete "${car.name}" from the fleet? This cannot be undone.`)) return;
  try {
    await LuxehireAPI.deleteCar(id);
    await loadFleet();
    renderOverview();
    renderFleetTable();
    populatePromoCarSelect();
    showToast("Vehicle deleted", "success");
  } catch (e) { showToast(e.message, "error"); }
}

/* ---- Add / Edit car form: image inputs (URL paste OR device upload) -----------*/
function buildImageInputs(values) {
  currentImages = values ? [...values] : [];
  renderImageInputs();
}
function renderImageInputs() {
  const wrap = document.getElementById("imageInputs");
  const slots = currentImages.length < 5 ? [...currentImages, ""] : [...currentImages];
  wrap.innerHTML = slots.map((v, i) => `
    <div class="image-input-row">
      <span class="icon icon-sm" data-icon="image"></span>
      <input type="url" class="img-url-input" data-idx="${i}" placeholder="Image URL ${i + 1}" value="${escAttr(v)}">
      <input type="file" class="img-file-input" data-idx="${i}" accept="image/png,image/jpeg,image/webp,image/gif" style="display:none;">
      <button type="button" class="btn btn-outline-dark btn-sm" data-upload-idx="${i}">Upload</button>
      ${v ? `<button type="button" class="btn btn-outline-dark btn-sm" data-remove-idx="${i}" title="Remove"><span class="icon icon-sm" data-icon="close"></span></button>` : ""}
    </div>`).join("");

  wrap.querySelectorAll(".img-url-input").forEach(inp => inp.addEventListener("change", e => {
    const idx = parseInt(e.target.getAttribute("data-idx"), 10);
    setImageAt(idx, e.target.value.trim());
  }));
  wrap.querySelectorAll("[data-upload-idx]").forEach(btn => btn.addEventListener("click", () => {
    const idx = parseInt(btn.getAttribute("data-upload-idx"), 10);
    wrap.querySelector(`.img-file-input[data-idx="${idx}"]`).click();
  }));
  wrap.querySelectorAll(".img-file-input").forEach(inp => inp.addEventListener("change", async e => {
    const idx = parseInt(e.target.getAttribute("data-idx"), 10);
    const file = e.target.files[0];
    if (!file) return;
    try {
      const url = await LuxehireAPI.uploadImage("cars", file);
      setImageAt(idx, url);
    } catch (err) { showToast(err.message, "error"); }
  }));
  wrap.querySelectorAll("[data-remove-idx]").forEach(btn => btn.addEventListener("click", () => {
    const idx = parseInt(btn.getAttribute("data-remove-idx"), 10);
    currentImages.splice(idx, 1);
    renderImageInputs();
    updateImagePreview();
  }));
  renderIcons(wrap);
  updateImagePreview();
}
function setImageAt(idx, url) {
  currentImages[idx] = url;
  currentImages = currentImages.filter(Boolean);
  renderImageInputs();
  updateImagePreview();
}
function updateImagePreview() {
  document.getElementById("imagePreviewStrip").innerHTML = currentImages.map(u => `<img src="${escAttr(u)}" alt="Preview" onerror="this.style.opacity=0.25">`).join("");
}

function bindCarForm() {
  const featInput = document.getElementById("f-feature-input");
  featInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      const val = featInput.value.trim();
      if (val && !currentFeatures.includes(val)) { currentFeatures.push(val); renderFeatureTags(); }
      featInput.value = "";
    }
  });

  document.getElementById("cancelEditBtn").addEventListener("click", resetCarForm);

  document.getElementById("carForm").addEventListener("submit", async e => {
    e.preventDefault();
    const images = currentImages.filter(Boolean);
    if (images.length === 0) { showToast("Add at least one image", "error"); return; }

    const carData = {
      name: document.getElementById("f-name").value.trim(),
      brand: document.getElementById("f-brand").value.trim(),
      category: document.getElementById("f-category").value.trim(),
      year: parseInt(document.getElementById("f-year").value, 10),
      seats: parseInt(document.getElementById("f-seats").value, 10),
      transmission: document.getElementById("f-transmission").value,
      fuel: document.getElementById("f-fuel").value,
      noDeposit: document.getElementById("f-nodeposit").value === "true",
      daily: parseFloat(document.getElementById("f-daily").value),
      weekly: parseFloat(document.getElementById("f-weekly").value),
      monthly: parseFloat(document.getElementById("f-monthly").value),
      depositFee: parseFloat(document.getElementById("f-depositfee").value) || 0,
      features: [...currentFeatures],
      images
    };

    try {
      if (editingCarId) {
        await LuxehireAPI.updateCar(editingCarId, carData);
        showToast("Vehicle updated successfully", "success");
      } else {
        await LuxehireAPI.createCar(carData);
        showToast("Vehicle added successfully", "success");
      }
      await loadFleet();
      resetCarForm();
      renderOverview();
      renderFleetTable();
      populatePromoCarSelect();
      switchTab("fleet");
    } catch (err) { showToast(err.message, "error"); }
  });
}

function renderFeatureTags() {
  document.getElementById("featureTags").innerHTML = currentFeatures.map((f, i) => `
    <span class="feature-tag">${esc(f)}<button type="button" data-remove-feat="${i}"><span class="icon icon-sm" data-icon="close"></span></button></span>
  `).join("");
  document.querySelectorAll("[data-remove-feat]").forEach(btn => {
    btn.addEventListener("click", () => { currentFeatures.splice(parseInt(btn.getAttribute("data-remove-feat"), 10), 1); renderFeatureTags(); });
  });
  renderIcons(document.getElementById("featureTags"));
}

function loadCarIntoForm(id) {
  const car = fleet.find(c => c.id === id);
  if (!car) return;
  editingCarId = id;
  document.getElementById("carFormTitle").textContent = "Edit " + car.name;
  document.getElementById("f-name").value = car.name;
  document.getElementById("f-brand").value = car.brand;
  document.getElementById("f-category").value = car.category;
  document.getElementById("f-year").value = car.year;
  document.getElementById("f-seats").value = car.seats;
  document.getElementById("f-transmission").value = car.transmission;
  document.getElementById("f-fuel").value = car.fuel;
  document.getElementById("f-nodeposit").value = String(car.noDeposit);
  document.getElementById("f-daily").value = car.daily;
  document.getElementById("f-weekly").value = car.weekly;
  document.getElementById("f-monthly").value = car.monthly;
  document.getElementById("f-depositfee").value = car.depositFee || 0;
  currentFeatures = [...car.features];
  renderFeatureTags();
  buildImageInputs(car.images);
  document.getElementById("cancelEditBtn").style.display = "inline-flex";
  switchTab("add-car");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function resetCarForm() {
  editingCarId = null;
  currentFeatures = [];
  document.getElementById("carForm").reset();
  document.getElementById("carFormTitle").textContent = "Add a new car";
  document.getElementById("cancelEditBtn").style.display = "none";
  renderFeatureTags();
  buildImageInputs();
}

/* ---- Customer hero images tab -------------------------------------------------*/
function bindHeroTab() {
  const fileInput = document.getElementById("hero-file");
  const uploadBtn = document.getElementById("hero-upload-btn");
  const addBtn = document.getElementById("hero-add-btn");
  const nameLabel = document.getElementById("hero-file-name");

  uploadBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    nameLabel.textContent = "Uploading…";
    try {
      pendingHeroUrl = await LuxehireAPI.uploadImage("hero", file);
      nameLabel.textContent = file.name;
      addBtn.disabled = false;
    } catch (e) {
      showToast(e.message, "error");
      nameLabel.textContent = "No file selected";
    }
  });

  addBtn.addEventListener("click", async () => {
    if (!pendingHeroUrl) return;
    const caption = document.getElementById("hero-caption").value.trim();
    try {
      await LuxehireAPI.addHeroImage({ url: pendingHeroUrl, caption });
      await loadHeroImages();
      renderHeroList();
      pendingHeroUrl = null;
      fileInput.value = "";
      document.getElementById("hero-caption").value = "";
      nameLabel.textContent = "No file selected";
      addBtn.disabled = true;
      showToast("Hero image added — live on the homepage now", "success");
    } catch (e) { showToast(e.message, "error"); }
  });
}
function renderHeroList() {
  const list = document.getElementById("heroList");
  list.innerHTML = heroImages.map(h => `
    <div class="hero-list-item">
      <img src="${escAttr(h.url)}" alt="${escAttr(h.caption || "")}">
      <button class="rm" data-hero-remove="${h.id}" aria-label="Remove"><span class="icon icon-sm" data-icon="close"></span></button>
    </div>`).join("") || `<p style="color:var(--steel-600);font-size:13.5px;">No hero images yet.</p>`;
  list.querySelectorAll("[data-hero-remove]").forEach(btn => btn.addEventListener("click", async () => {
    if (!confirm("Remove this hero image from the homepage?")) return;
    try {
      await LuxehireAPI.deleteHeroImage(btn.getAttribute("data-hero-remove"));
      await loadHeroImages();
      renderHeroList();
      showToast("Hero image removed", "success");
    } catch (e) { showToast(e.message, "error"); }
  }));
  renderIcons(list);
}

/* ---- Promo cars tab -------------------------------------------------------------*/
function populatePromoCarSelect() {
  const sel = document.getElementById("promo-car-select");
  sel.innerHTML = fleet.map(c => `<option value="${escAttr(c.id)}">${esc(c.name)} — AED ${fmt(c.daily)}/day</option>`).join("");
}
function bindPromoTab() {
  document.getElementById("promo-add-btn").addEventListener("click", async () => {
    const carId = document.getElementById("promo-car-select").value;
    const badgeText = document.getElementById("promo-badge").value.trim() || "Promo";
    if (!carId) { showToast("Add a car to the fleet first", "error"); return; }
    try {
      await LuxehireAPI.addPromoCar({ carId, badgeText });
      await loadPromoCars();
      renderPromoList();
      document.getElementById("promo-badge").value = "Promo";
      showToast("Promo car added — live on the homepage now", "success");
    } catch (e) { showToast(e.message, "error"); }
  });
}
function renderPromoList() {
  const list = document.getElementById("promoList");
  list.innerHTML = promoCars.map(p => `
    <div class="promo-list-item">
      <img src="${escAttr(p.car.images[0])}" alt="${escAttr(p.car.name)}">
      <span class="label">${esc(p.badgeText)} — ${esc(p.car.name)}</span>
      <button class="rm" data-promo-remove="${p.id}" aria-label="Remove"><span class="icon icon-sm" data-icon="close"></span></button>
    </div>`).join("") || `<p style="color:var(--steel-600);font-size:13.5px;">No promo cars yet.</p>`;
  list.querySelectorAll("[data-promo-remove]").forEach(btn => btn.addEventListener("click", async () => {
    if (!confirm("Remove this promo car from the homepage?")) return;
    try {
      await LuxehireAPI.deletePromoCar(btn.getAttribute("data-promo-remove"));
      await loadPromoCars();
      renderPromoList();
      showToast("Promo car removed", "success");
    } catch (e) { showToast(e.message, "error"); }
  }));
  renderIcons(list);
}

/* ---- Settings ---------------------------------------------------------------*/
function fillSettingsForm() {
  LuxehireAPI.getConfig().then(cfg => {
    document.getElementById("s-whatsapp").value = cfg.whatsapp;
    document.getElementById("s-email").value = cfg.email;
    document.getElementById("s-address").value = cfg.address;
  });
}

function bindSettingsForm() {
  document.getElementById("settingsForm").addEventListener("submit", async e => {
    e.preventDefault();
    const wa = document.getElementById("s-whatsapp").value.trim().replace(/\D/g, "");
    if (!wa || wa.length < 8) { showToast("Enter a valid WhatsApp number with country code", "error"); return; }
    try {
      await LuxehireAPI.updateConfig({
        whatsapp: wa,
        email: document.getElementById("s-email").value.trim(),
        address: document.getElementById("s-address").value.trim()
      });
      showToast("Settings saved — live on the site now", "success");
    } catch (e) { showToast(e.message, "error"); }
  });
}

function bindPasswordForm() {
  document.getElementById("passwordForm").addEventListener("submit", async e => {
    e.preventDefault();
    const current = document.getElementById("p-current").value;
    const next = document.getElementById("p-new").value;
    try {
      await LuxehireAPI.changePassword(current, next);
      document.getElementById("passwordForm").reset();
      showToast("Password updated successfully", "success");
    } catch (err) { showToast(err.message, "error"); }
  });
}

/* ---- Data management ----------------------------------------------------------*/
function bindDataButtons() {
  document.getElementById("exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(fleet, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "luxehire-fleet-backup.json";
    a.click();
    URL.revokeObjectURL(url);
    showToast("Fleet exported", "success");
  });

  document.getElementById("resetBtn").addEventListener("click", async () => {
    if (!confirm("Reset the entire fleet to the default demo cars? This will remove any cars you've added or edited.")) return;
    try {
      await LuxehireAPI.resetFleet();
      await loadFleet();
      renderOverview();
      renderFleetTable();
      populatePromoCarSelect();
      showToast("Fleet reset to demo data", "success");
    } catch (e) { showToast(e.message, "error"); }
  });
}

/* ---- Logout ---------------------------------------------------------------------*/
function bindLogout() {
  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await LuxehireAPI.logout();
    window.location.href = "login.html";
  });
  document.getElementById("viewSiteBtn").addEventListener("click", () => {
    window.open("../index.html", "_blank");
  });
}

/* ---- Mobile sidebar toggle -----------------------------------------------------------*/
function bindSidebarToggle() {
  const toggle = document.getElementById("sidebarToggle");
  const sidebar = document.getElementById("adminSidebar");
  const overlay = document.getElementById("sidebarOverlay");
  if (!toggle || !sidebar || !overlay) return;
  toggle.addEventListener("click", () => { sidebar.classList.add("open"); overlay.classList.add("show"); });
  overlay.addEventListener("click", () => { sidebar.classList.remove("open"); overlay.classList.remove("show"); });
  document.querySelectorAll(".admin-nav button[data-tab]").forEach(b => b.addEventListener("click", () => { sidebar.classList.remove("open"); overlay.classList.remove("show"); }));
}

/* ---- Toast ------------------------------------------------------------------------*/
let toastTimer = null;
function showToast(msg, type) {
  const toast = document.getElementById("toast");
  document.getElementById("toastMsg").textContent = msg;
  toast.className = "toast show " + (type || "success");
  toast.querySelector(".icon").setAttribute("data-icon", type === "error" ? "close" : "check");
  toast.querySelector(".icon").innerHTML = "";
  toast.querySelector(".icon").dataset.iconRendered = "";
  renderIcons(toast);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

/* ---- Helpers -----------------------------------------------------------------------*/
function fmt(n) { return Number(n).toLocaleString("en-AE"); }
function esc(s) { return String(s).replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])); }
function escAttr(s) { return esc(s); }
