/* ==========================================================================
   Luxehire — API client. Talks to the real backend. No localStorage,
   no client-side "database" — everything lives on the server now.
   ========================================================================== */

const LuxehireAPI = {
  csrfToken: null,

  async getFleet() {
    const r = await fetch("/api/fleet");
    if (!r.ok) throw new Error("Failed to load fleet");
    return r.json();
  },
  async getConfig() {
    const r = await fetch("/api/config");
    if (!r.ok) throw new Error("Failed to load config");
    return r.json();
  },
  async getHeroImages() {
    const r = await fetch("/api/hero-images");
    if (!r.ok) throw new Error("Failed to load hero images");
    return r.json();
  },
  async getPromoCars() {
    const r = await fetch("/api/promo-cars");
    if (!r.ok) throw new Error("Failed to load promo cars");
    return r.json();
  },

  /* ---- Admin ---- */
  async _adminFetch(url, options = {}) {
    const headers = Object.assign({ "Content-Type": "application/json" }, options.headers || {});
    if (this.csrfToken) headers["X-CSRF-Token"] = this.csrfToken;
    const r = await fetch(url, Object.assign({ credentials: "same-origin" }, options, { headers }));
    let data = null;
    try { data = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) throw new Error((data && data.error) || `Request failed (${r.status})`);
    return data;
  },
  async login(password) {
    const data = await this._adminFetch("/api/admin/login", { method: "POST", body: JSON.stringify({ password }) });
    this.csrfToken = data.csrfToken;
    return data;
  },
  async logout() {
    try { await this._adminFetch("/api/admin/logout", { method: "POST" }); } catch (e) {}
    this.csrfToken = null;
  },
  async me() {
    const data = await this._adminFetch("/api/admin/me", { method: "GET" });
    this.csrfToken = data.csrfToken;
    return data;
  },
  async changePassword(currentPassword, newPassword) {
    return this._adminFetch("/api/admin/change-password", { method: "POST", body: JSON.stringify({ currentPassword, newPassword }) });
  },
  async createCar(car) {
    return this._adminFetch("/api/admin/fleet", { method: "POST", body: JSON.stringify(car) });
  },
  async updateCar(id, car) {
    return this._adminFetch(`/api/admin/fleet/${encodeURIComponent(id)}`, { method: "PUT", body: JSON.stringify(car) });
  },
  async deleteCar(id) {
    return this._adminFetch(`/api/admin/fleet/${encodeURIComponent(id)}`, { method: "DELETE" });
  },
  async resetFleet() {
    return this._adminFetch("/api/admin/fleet-reset", { method: "POST" });
  },
  async updateConfig(cfg) {
    return this._adminFetch("/api/admin/config", { method: "PUT", body: JSON.stringify(cfg) });
  },
  async addHeroImage(entry) {
    return this._adminFetch("/api/admin/hero-images", { method: "POST", body: JSON.stringify(entry) });
  },
  async deleteHeroImage(id) {
    return this._adminFetch(`/api/admin/hero-images/${encodeURIComponent(id)}`, { method: "DELETE" });
  },
  async addPromoCar(entry) {
    return this._adminFetch("/api/admin/promo-cars", { method: "POST", body: JSON.stringify(entry) });
  },
  async deletePromoCar(id) {
    return this._adminFetch(`/api/admin/promo-cars/${encodeURIComponent(id)}`, { method: "DELETE" });
  },
  async getOverview() {
    return this._adminFetch("/api/admin/overview", { method: "GET" });
  },
  /** category: "cars" | "hero" | "promo". file: a File object from an <input type=file>. */
  async uploadImage(category, file) {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
    const data = await this._adminFetch(`/api/admin/upload/${category}`, { method: "POST", body: JSON.stringify({ dataUrl }) });
    return data.url;
  }
};
