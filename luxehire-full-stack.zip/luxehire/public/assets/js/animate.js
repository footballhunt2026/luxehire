/* ==========================================================================
   Luxehire — lightweight scroll-reveal. Add data-animate to any element;
   optional data-animate-delay="1".."6" staggers children.
   ========================================================================== */
(function () {
  function initReveal(scope) {
    const root = scope || document;
    const els = root.querySelectorAll("[data-animate]:not(.in-view)");
    if (!("IntersectionObserver" in window) || els.length === 0) {
      els.forEach(el => el.classList.add("in-view"));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    els.forEach(el => io.observe(el));
  }
  document.addEventListener("DOMContentLoaded", () => initReveal());
  window.LuxehireAnimate = { initReveal };
})();
