/* ==========================================================================
   Luxehire — Data store
   Tiny JSON-file database. No external DB needed for a small business
   site like this. Each "table" is one file in server/data/. Writes are
   queued per-file so two requests can never interleave and corrupt a file.
   ========================================================================== */
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const queues = new Map(); // filename -> Promise chain, serializes writes

function filePath(name) {
  return path.join(DATA_DIR, name + ".json");
}

function readJSON(name, fallback) {
  const fp = filePath(name);
  if (!fs.existsSync(fp)) {
    writeJSONSync(name, fallback);
    return JSON.parse(JSON.stringify(fallback));
  }
  try {
    return JSON.parse(fs.readFileSync(fp, "utf8"));
  } catch (e) {
    console.error(`[store] Failed to parse ${name}.json, restoring fallback:`, e.message);
    writeJSONSync(name, fallback);
    return JSON.parse(JSON.stringify(fallback));
  }
}

function writeJSONSync(name, data) {
  const fp = filePath(name);
  const tmp = fp + "." + crypto.randomBytes(4).toString("hex") + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, fp); // atomic on same filesystem
}

/** Queue a read-modify-write so concurrent admin requests can't clobber each other. */
function update(name, fallback, mutator) {
  const prev = queues.get(name) || Promise.resolve();
  const next = prev
    .catch(() => {})
    .then(() => {
      const data = readJSON(name, fallback);
      const result = mutator(data);
      writeJSONSync(name, data);
      return result;
    });
  queues.set(name, next);
  return next;
}

module.exports = { readJSON, writeJSONSync, update, DATA_DIR };
