/* ==========================================================================
   Luxehire — Seed / default data
   Used only the FIRST time the server runs (to create the JSON files in
   server/data/). After that, everything is read from and written to those
   files — this module is never touched again.
   ========================================================================== */
"use strict";

const DEFAULT_FLEET = [
  { id: "c1", name: "Range Rover Vogue", brand: "Land Rover", category: "SUV", seats: 5, transmission: "Automatic", fuel: "Petrol", year: 2024, daily: 950, weekly: 5800, monthly: 19500, noDeposit: true, depositFee: 350,
    features: ["Panoramic Sunroof", "Leather Seats", "360° Camera", "Cruise Control", "Bluetooth", "Air Conditioning"],
    images: [
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=900&q=80",
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900&q=80",
      "https://images.unsplash.com/photo-1606611013016-969c19ba27bb?w=900&q=80",
      "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=900&q=80",
      "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=900&q=80"
    ] },
  { id: "c2", name: "Mercedes-Benz S-Class", brand: "Mercedes-Benz", category: "Luxury Sedan", seats: 5, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 850, weekly: 5100, monthly: 17000, noDeposit: true, depositFee: 300,
    features: ["Massage Seats", "Ambient Lighting", "Burmester Sound", "Adaptive Cruise", "Heated Seats", "Wireless Charging"],
    images: [
      "https://images.unsplash.com/photo-1563720223185-11003d516935?w=900&q=80",
      "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=900&q=80",
      "https://images.unsplash.com/photo-1622200294737-08753b1f7d92?w=900&q=80",
      "https://images.unsplash.com/photo-1605515298946-d664e75ea67a?w=900&q=80",
      "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=900&q=80"
    ] },
  { id: "c3", name: "Lamborghini Huracán", brand: "Lamborghini", category: "Sports Car", seats: 2, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 3200, weekly: 19500, monthly: 65000, noDeposit: true, depositFee: 1200,
    features: ["Carbon Fiber Trim", "Sport Exhaust", "Launch Control", "Reverse Camera", "Alcantara Interior", "Racing Seats"],
    images: [
      "https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?w=900&q=80",
      "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=900&q=80",
      "https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=900&q=80",
      "https://images.unsplash.com/photo-1621135802920-133df287f89c?w=900&q=80",
      "https://images.unsplash.com/photo-1592198084033-aade902d1aae?w=900&q=80"
    ] },
  { id: "c4", name: "BMW 7 Series", brand: "BMW", category: "Luxury Sedan", seats: 5, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 780, weekly: 4700, monthly: 15800, noDeposit: true, depositFee: 280,
    features: ["Executive Lounge Seats", "Sky Lounge Roof", "Gesture Control", "Harman Kardon Audio", "Night Vision", "Parking Assist"],
    images: [
      "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=900&q=80",
      "https://images.unsplash.com/photo-1523983388277-336a66bf9bcd?w=900&q=80",
      "https://images.unsplash.com/photo-1607853202273-797f1c22a38e?w=900&q=80",
      "https://images.unsplash.com/photo-1617531653332-bd46c24f2068?w=900&q=80",
      "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=900&q=80"
    ] },
  { id: "c5", name: "Toyota Camry", brand: "Toyota", category: "Economy Sedan", seats: 5, transmission: "Automatic", fuel: "Petrol", year: 2024, daily: 150, weekly: 900, monthly: 2900, noDeposit: true, depositFee: 80,
    features: ["Air Conditioning", "Bluetooth", "USB Charging", "Cruise Control", "Rear Camera", "Alloy Wheels"],
    images: [
      "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=900&q=80",
      "https://images.unsplash.com/photo-1621007806229-6b8dfa1e5b16?w=900&q=80",
      "https://images.unsplash.com/photo-1617469767053-8f35aaa39b2f?w=900&q=80",
      "https://images.unsplash.com/photo-1616422285623-13ff0162193c?w=900&q=80",
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=900&q=80"
    ] },
  { id: "c6", name: "Nissan Patrol", brand: "Nissan", category: "SUV", seats: 7, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 420, weekly: 2550, monthly: 8500, noDeposit: true, depositFee: 150,
    features: ["7 Seater", "Bose Sound System", "Around View Monitor", "Cooled Seats", "Sunroof", "Off-Road Mode"],
    images: [
      "https://images.unsplash.com/photo-1568844293986-8d0400bd4745?w=900&q=80",
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900&q=80",
      "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=900&q=80",
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=900&q=80",
      "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=900&q=80"
    ] },
  { id: "c7", name: "Porsche 911 Carrera", brand: "Porsche", category: "Sports Car", seats: 2, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 1800, weekly: 10900, monthly: 36500, noDeposit: true, depositFee: 700,
    features: ["Sport Chrono Package", "PASM Suspension", "Bose Surround", "Carbon Interior", "Sport Exhaust", "Reverse Camera"],
    images: [
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900&q=80",
      "https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=900&q=80",
      "https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?w=900&q=80",
      "https://images.unsplash.com/photo-1621135802920-133df287f89c?w=900&q=80",
      "https://images.unsplash.com/photo-1592198084033-aade902d1aae?w=900&q=80"
    ] },
  { id: "c8", name: "Audi Q8", brand: "Audi", category: "SUV", seats: 5, transmission: "Automatic", fuel: "Petrol", year: 2023, daily: 650, weekly: 3900, monthly: 13200, noDeposit: true, depositFee: 240,
    features: ["Matrix LED Headlights", "Virtual Cockpit", "Bang & Olufsen Audio", "Quattro AWD", "Panoramic Roof", "Adaptive Air Suspension"],
    images: [
      "https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?w=900&q=80",
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=900&q=80",
      "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=900&q=80",
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900&q=80",
      "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=900&q=80"
    ] }
];

const DEFAULT_CONFIG = {
  whatsapp: "971500000000",
  siteName: "Luxehire Car Rental",
  email: "hello.luxeridecarrental@gmail.com",
  domain: "luxehirecarrental.xyz",
  address: "Sheikh Zayed Road, Dubai, United Arab Emirates"
};

const DEFAULT_HERO_IMAGES = [];
const DEFAULT_PROMO_CARS = [];

module.exports = { DEFAULT_FLEET, DEFAULT_CONFIG, DEFAULT_HERO_IMAGES, DEFAULT_PROMO_CARS };
