/* ==========================================================================
   Luxehire — Admin auth
   Password hashing (scrypt, built into Node — no bcrypt dependency needed),
   opaque server-side sessions (httpOnly cookie, nothing sensitive in the
   token itself), CSRF tokens for state-changing requests, and a simple
   in-memory rate limiter for the login endpoint.
   ========================================================================== */
"use strict";

const crypto = require("crypto");
const store = require("./store");

const SESSION_COOKIE = "luxehire_admin_session";
const SESSION_TTL_MS = 60 * 60 * 1000; // 1 hour idle timeout
const sessions = new Map(); // token -> { expires, csrf }

const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = 8;
const loginAttempts = new Map(); // ip -> { count, windowStart }

/* ---- Password hashing (scrypt) -------------------------------------------- */
function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const attempt = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (attempt.length !== expected.length) return false;
  return crypto.timingSafeEqual(attempt, expected);
}

/* ---- Bootstrap admin record ------------------------------------------------ */
function ensureAdmin() {
  const fp = require("path").join(store.DATA_DIR, "admin.json");
  const fs = require("fs");
  if (fs.existsSync(fp)) return;

  const provided = process.env.ADMIN_PASSWORD && String(process.env.ADMIN_PASSWORD).trim();
  const password = provided || crypto.randomBytes(9).toString("base64url");
  const { salt, hash } = hashPassword(password);
  store.writeJSONSync("admin", { salt, hash });

  console.log("\n================ LUXEHIRE ADMIN — FIRST RUN ================");
  if (provided) {
    console.log("Admin account created using ADMIN_PASSWORD from your .env file.");
  } else {
    console.log("No ADMIN_PASSWORD set in .env — a random password was generated:");
    console.log("  Password: " + password);
    console.log("Save it now. Log in at /admin/login.html, then change it");
    console.log("immediately from Settings.");
  }
  console.log("==============================================================\n");
}

/* ---- Sessions --------------------------------------------------------------- */
function createSession() {
  const token = crypto.randomBytes(32).toString("hex");
  const csrf = crypto.randomBytes(24).toString("hex");
  sessions.set(token, { expires: Date.now() + SESSION_TTL_MS, csrf });
  return { token, csrf };
}

function getSession(token) {
  if (!token) return null;
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() > s.expires) {
    sessions.delete(token);
    return null;
  }
  s.expires = Date.now() + SESSION_TTL_MS; // sliding expiry
  return s;
}

function destroySession(token) {
  if (token) sessions.delete(token);
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  header.split(";").forEach(part => {
    const idx = part.indexOf("=");
    if (idx === -1) return;
    const k = part.slice(0, idx).trim();
    const v = part.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  });
  return out;
}

/* ---- Login rate limiting (per IP) ------------------------------------------- */
function isRateLimited(ip) {
  const rec = loginAttempts.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.windowStart > LOGIN_WINDOW_MS) {
    loginAttempts.delete(ip);
    return false;
  }
  return rec.count >= LOGIN_MAX_ATTEMPTS;
}

function recordLoginFailure(ip) {
  const rec = loginAttempts.get(ip);
  if (!rec || Date.now() - rec.windowStart > LOGIN_WINDOW_MS) {
    loginAttempts.set(ip, { count: 1, windowStart: Date.now() });
  } else {
    rec.count++;
  }
}

function clearLoginFailures(ip) {
  loginAttempts.delete(ip);
}

module.exports = {
  SESSION_COOKIE,
  hashPassword,
  verifyPassword,
  ensureAdmin,
  createSession,
  getSession,
  destroySession,
  parseCookies,
  isRateLimited,
  recordLoginFailure,
  clearLoginFailures
};
